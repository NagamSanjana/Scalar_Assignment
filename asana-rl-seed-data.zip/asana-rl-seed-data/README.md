## Setup
pip install -r requirements.txt

## Run
python src/main.py

## Output
The SQLite database will be generated at output/asana_simulation.sqlite
